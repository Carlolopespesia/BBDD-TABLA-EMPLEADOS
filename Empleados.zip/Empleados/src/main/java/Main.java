import java.lang.reflect.Type;
import java.sql.*;
import java.util.Arrays;
import java.util.Properties;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // La url estaba mal... debía poner la de abajao para conectar directamente con la base de datos
        final String url = "jdbc:postgresql://localhost:5432/CINELOKO";

        // Establecemos todas las credenciales con un objeto llamado Properties
        final Properties props = new Properties();
        props.setProperty("user", "postgres");
        props.setProperty("password", "postgres");

        // Declaramos la query en cuestión
        String query = "SELECT * FROM empleados;";

        //Bloque try/catch para contemplar errores a la hora de hacer la conexión
        try
        // La memoria de las variables declaradas desntro del parentésis del try es borrada una vez que finlaiza el bloque try
        (
                Connection conn = DriverManager.getConnection(url, props);
                Statement statement = conn.createStatement()
        ) {
            System.out.println("Versión de la base de datos");
            System.out.println(conn.getMetaData().getDatabaseProductVersion());

            ResultSet resultSet = statement.executeQuery(query);

            // Imprimir encabezados (Opcional, requiere usar ResultSetMetaData)
            System.out.println("Resultados de la Query:");

            while (resultSet.next()) {
                // Extraer los valores por el nombre de la columna o su índice (empezando en 1)
                int id = resultSet.getInt("id_empleado");
                String valor1 = resultSet.getString("nombre");
                String puesto = resultSet.getString("puesto");
                String tipoJornada = resultSet.getString("tipo_jornada");
                String email = resultSet.getString("email");
                int telefono = resultSet.getInt("telefono");
                String fContratacion = resultSet.getString("fecha_contratacion");
                Float sHora = resultSet.getFloat("salario_hora");
                Boolean activo = resultSet.getBoolean("activo");

                // Imprimir los valores en la consola
                System.out.println("ID: " + id);
                System.out.println("Nombre: " + valor1);
                System.out.println("Puesto: " + puesto);
                System.out.println("Tipo de Jornada: " + tipoJornada);
                System.out.println("Email: " + email);
                System.out.println("Teléfono: " + telefono);
                System.out.println("Fecha de Contratación: " + fContratacion);
                System.out.println("Salario por Hora: " + sHora);
                System.out.println("Activo: " + activo);
                System.out.println("-------------------------------------------------------");
            }
        } catch(SQLException e) {
            System.out.println("Error connecting to database " + Arrays.toString(e.getStackTrace()));
        }
        Scanner sc = new Scanner(System.in);
        Boolean continuar = true;
        while(continuar) {
            System.out.println("¿Qué acción quieres hacer en la tabla empleados?");
            System.out.println("(1) Leer");
            System.out.println("(2) Añadir");
            System.out.println("(3) Modificar");
            System.out.println("(4) Eliminar");
            System.out.println("(5) Salir");

            System.out.print("Introduce la opción con el número asiganada a cada una: ");
            // Incluimos en el paréntesis del try la variable scanner, así me despreocupo después de eliminarla
            Boolean ctr1 = true;
            try{
                int opcion = sc.nextInt();
                while(ctr1){
                    ctr1 = false;
                    if(opcion == 1){
                        System.out.println("Has elegido LEER");
                    }else if(opcion == 2){
                        System.out.println("Has elegido AÑADIR");
                    }else if(opcion == 3){
                        System.out.println("Has elegido MODIFICAR");
                    }else if(opcion == 4){
                        System.out.println("Has elegido ELIMINAR");
                    }else if(opcion == 5){
                        System.out.println("Has elegido Salir");
                        continuar = false;
                    }else{
                        System.out.println("NO HAS ELEGIDO UNA OPCIÓN CORRECTA");
                        ctr1 = true;
                        System.out.println("Elige una opción correcta: ");
                        System.out.println("(1) Leer");
                        System.out.println("(2) Añadir");
                        System.out.println("(3) Modificar");
                        System.out.println("(4) Eliminar");
                        System.out.println("(5) Salir");
                        opcion = sc.nextInt();
                    }
                    System.out.println("LA CAPA DE ELECCIÓN HA SIDO SUPERADA");
                    System.out.println("¿Quieres volver a hacer una query? (s/n)");
                    String volverQuery = sc.next();
                    if(volverQuery.equalsIgnoreCase("n")){
                        continuar = false;
                    }
                }
            }catch(ClassCastException e){
                System.out.println("Debes ingresar un número...");
            }catch(Exception e){
                System.out.println("Esto pasa: "+e.getMessage());
            }
        }
        sc.close();
        System.out.println("FIN DEL PROGRAMA!!!!!");
    }
}
