package Service;

import Repository.EmpleadoRepository;

import java.sql.Statement;

public class EmpleadosService {

    EmpleadoRepository bbddrepo = new EmpleadoRepository();

    Statement conextion = bbddrepo.conexionBBDD(bbddrepo.getUrl(), bbddrepo.getProps());

    public EmpleadosService(){
        this.bbddrepo = bbddrepo;
        this.conextion = conextion;
    }

    // RECOGER () getall

    public String findallempleados(){
        String outputlectura = bbddrepo.leerTodaTabala(conextion);

        if(!outputlectura.equals("")){
            return outputlectura;
        }else{
            return "No se ha logrado imprimir correctamente la tabla...";
        }
    }

    public String findallempleadosID(String id){
        String outputlectura = bbddrepo.leerTablaID(conextion, id);

        if(!outputlectura.equals("")){
            return outputlectura;
        }else{
            return "No se ha logrado imprimir correctamente la tabla...";
        }
    }

    // INSERTAR()

    public void insertarDatos(
            String nombre,
            String puesto,
            String tipoJornada,
            String email,
            String telefono,
            String fechaContratacion,
            double salarioHora,
            boolean activo,
            String departamento
    ){
        bbddrepo.insertarDatos(
                conextion,
                nombre,
                puesto,
                tipoJornada,
                email,
                telefono,
                fechaContratacion,
                salarioHora,
                activo,
                departamento
        );

        System.out.println("FILA INSERTADA CON ÉXITO :D");
    }

    // BORRAR ()
    public void eliminarDatosfila(String id){
        int filasIniciales = bbddrepo.contarFilas(conextion);
        bbddrepo.eliminarDatosfilaID(conextion, id);
        int filasFinales = bbddrepo.contarFilas(conextion);
        if(filasIniciales==filasFinales){
            System.out.println("No se ha eliminado nada....");
        }else if(filasIniciales<filasFinales){
            System.out.println("Algo ha ido muy mal xd");
        }else if(filasFinales!=0){
            System.out.println("Se ha eliminado la fila con id="+id+" con éxito :D");
        }else{
            System.out.println("Algo ha ido mal...");
        }
    }

    public void eliminarDatosfilaAPartirID(String id){
        int filasIniciales = bbddrepo.contarFilas(conextion);
        bbddrepo.eliminarDatosfilaAPartirID(conextion, id);
        int filasFinales = bbddrepo.contarFilas(conextion);
        if(filasIniciales==filasFinales){
            System.out.println("No se ha eliminado nada....");
        }else if(filasIniciales<filasFinales){
            System.out.println("Algo ha ido muy mal xd");
        }else if(filasFinales!=0){
            System.out.println("Se ha eliminado TODAS las filas a partir del id="+id+" (sin incluir) con éxito :D");
        }else{
            System.out.println("Algo ha ido mal...");
        }
    }


    // UPDATE ()

    public void modificarTabla(String id, String campo, Object valor){
        bbddrepo.modificarTabla(conextion, id, campo, valor);
        System.out.println("DATO MODIFICADO CON ÉXITO");
    }



}
