package Service;

import Repository.EmpleadoRepository;

import java.sql.Statement;

public class EmpleadosService {

    EmpleadoRepository bbddrepo = new EmpleadoRepository();

    Statement conextion = bbddrepo.conexionBBDD(bbddrepo.getUrl(), bbddrepo.getProps());

    public EmpleadosService(){
        this.bbddrepo = bbddrepo;
        this.conextion = conextion;
    }

    // RECOGER () getall

    public String findallempleados(){
        String outputlectura = bbddrepo.leerTodaTabala(conextion);

        if(!outputlectura.equals("")){
            return outputlectura;
        }else{
            return "No se ha logrado imprimir correctamente la tabla...";
        }
    }

    public String findallempleadosID(String id){
        String outputlectura = bbddrepo.leerTablaID(conextion, id);

        if(!outputlectura.equals("")){
            return outputlectura;
        }else{
            return "No se ha logrado imprimir correctamente la tabla...";
        }
    }

    // INSERTAR()

    public void insertarDatos(
            String nombre,
            String puesto,
            String tipoJornada,
            String email,
            String telefono,
            String fechaContratacion,
            double salarioHora,
            boolean activo,
            String departamento
    ){
        bbddrepo.insertarDatos(
                conextion,
                nombre,
                puesto,
                tipoJornada,
                email,
                telefono,
                fechaContratacion,
                salarioHora,
                activo,
                departamento
        );

        System.out.println("FILA INSERTADA CON ÉXITO :D");
    }

    // BORRAR ()

    // UPDATE ()




}
