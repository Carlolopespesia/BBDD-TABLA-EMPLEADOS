package Repository;

import java.sql.*;
import java.util.Arrays;
import java.util.Properties;


public class EmpleadoRepository {

    //Definimos una url de la base de datos
    String url = "jdbc:postgresql://localhost:5432/CINELOKO";
    Properties props = new Properties();

    // El constructor con parámetros ya está bien si quieres usarlos
    public EmpleadoRepository(String url, Properties props) {
        this.url = url;
        this.props = props;
    }

    // Constructor sin argumentos: ¡Configuramos las propiedades aquí!
    public EmpleadoRepository() {
        // La url y props ya se inicializan arriba, solo necesitamos configurar props
        this.props.setProperty("user", "postgres");
        this.props.setProperty("password", "postgres");
        // No es necesario: this.url = url; o this.props = props; porque ya se hizo arriba
    }

    public Statement conexionBBDD(String url, Properties props){
        try{
            //Estos dos los había puesto en el paréntesis de try para manejar su memoria, pero eso hacía que se perdiera la conexión co la BBDD al finalizar el try
            // ********************************************************************
            Connection conn = DriverManager.getConnection(url, props);
            Statement statement = conn.createStatement();
            // ********************************************************************
            System.out.println("Versión de la base de datos");
            System.out.println(conn.getMetaData().getDatabaseProductVersion());
            return statement;
        }catch(SQLException e){
            System.out.println("Error connecting to database " + Arrays.toString(e.getStackTrace()));
        }
        return null;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Properties getProps() {
        return props;
    }

    public void setProps(Properties props) {
        this.props = props;
    }

    public String leerTablaID(Statement conexionBBDD, String id){
        String query = "SELECT *\n" +
                "FROM empleados_bueno\n" +
                "WHERE empleados_bueno.id_empleado ="+id+";";
        return leerTabla(conexionBBDD, query);
    }

    public String leerTodaTabala(Statement conexionBBDD){
        String query = "SELECT * FROM empleados_bueno;";
        return leerTabla(conexionBBDD, query);
    }

    public String leerTabla(Statement conexionBBDD, String query){
        try{
            ResultSet resultSet = conexionBBDD.executeQuery(query);
            String datosEmpleado = "";
            while (resultSet.next()) {
                // Extraer los valores por el nombre de la columna o su índice (empezando en 1)
                int id = resultSet.getInt("id_empleado");
                String valor1 = resultSet.getString("nombre");
                String puesto = resultSet.getString("puesto");
                String tipoJornada = resultSet.getString("tipo_jornada");
                String email = resultSet.getString("email");
                int telefono = resultSet.getInt("telefono");
                String fContratacion = resultSet.getString("fecha_contratacion");
                Float sHora = resultSet.getFloat("salario_hora");
                Boolean activo = resultSet.getBoolean("activo");

                // Inicializamos un String con la primera línea o un separador
                datosEmpleado += "-----------------------------------\n";

                // Concatenamos cada línea usando "\n" para el salto de línea
                datosEmpleado += "ID: " + id + "\n";
                datosEmpleado += "Nombre: " + valor1 + "\n"; // Asumiendo que 'valor1' es el nombre
                datosEmpleado += "Puesto: " + puesto + "\n";
                datosEmpleado += "Tipo de Jornada: " + tipoJornada + "\n";
                datosEmpleado += "Email: " + email + "\n";
                datosEmpleado += "Teléfono: " + telefono + "\n";
                datosEmpleado += "Fecha de Contratación: " + fContratacion + "\n";
                datosEmpleado += "Salario por Hora: " + sHora + "\n";
                datosEmpleado += "Activo: " + activo + "\n";
                datosEmpleado += "-----------------------------------\n";
            }
            // Devolvemos el string completo una sola vez
            return datosEmpleado;
        } catch (SQLException e) {
            System.out.println("Error connecting to database " + Arrays.toString(e.getStackTrace()));
        }
        return "";
    }

    public void insertarDatos(Statement conexionBBDD,
                              String nombre,
                              String puesto,
                              String tipoJornada,
                              String email,
                              String telefono,
                              String fechaContratacion,
                              double salarioHora,
                              boolean activo,
                              String departamento){

        try{
            String query = "INSERT INTO empleados_bueno (" +
                    "nombre, puesto, tipo_jornada, email, telefono, fecha_contratacion, salario_hora, activo, departamento) " +
                    "VALUES ('" + nombre + "', '" + puesto + "', '" + tipoJornada + "', '" + email + "', '" + telefono + "', '" + fechaContratacion + "', " + salarioHora + ", " + activo + ",'" + departamento +"');";
//          conexionBBDD.executeQuery(query);
            // Uso esto en vez de lo anterior ya que esto no necesita devolver nada, y así no hay errores
            conexionBBDD.executeUpdate(query);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public int contarFilas(Statement conexionBBDD){

        // El mejor método es siempre usar try-with-resources para cerrar ResultSet
        String query = "SELECT COUNT(*) FROM empleados_bueno;";

        // Declaramos el ResultSet fuera del try-with-resources si no podemos usarlo.
        // Aunque en este caso, lo mejor es el try-with-resources si usaras Connection.

        // Lo más simple en tu contexto actual (usando Statement):
        try {
            // 1. Ejecutar la consulta. Devuelve un ResultSet.
            ResultSet rs = conexionBBDD.executeQuery(query);

            // 2. Mover el cursor a la primera (y única) fila de resultados.
            if (rs.next()) {
                // 3. Obtener el valor de la primera columna (donde está COUNT(*))
                // Se usa 1 para la primera columna o el alias si le pusieras uno.
                int numFilas = rs.getInt(1);

                // 4. Cerrar el ResultSet inmediatamente (aunque con Statement se suele cerrar todo)
                rs.close();

                return numFilas;
            }

            return 0;


        } catch (SQLException e) {
            // Debes manejar la excepción o lanzarla (como se hace aquí)
            System.err.println("Error al contar las filas: " + e.getMessage());
            // Propagar la excepción es una buena práctica en la capa de repositorio
            // En caso de que no haya resultado (aunque COUNT(*) siempre devuelve uno)
            return 0;
        }
    }



    public void eliminarDatosfilaID(Statement conexionBBDD, String id){
        try{
            // Esto solo lo voy a probar una vez, a ver si funciona...
            // String query = "DELETE FROM empleados_bueno WHERE id_empleado="+id+";";
            String query = "DELETE FROM empleados_bueno WHERE id_empleado=?;";
            Connection lol = conexionBBDD.getConnection();
            PreparedStatement pstmt = lol.prepareStatement(query);
            //Lo de abajo no funciona ya que he puesto para que lea un String, no un int...
//            pstmt.setString(1, Integer.parseInt(id));
            pstmt.setInt(1, Integer.parseInt(id));

            // Ejecuta la inserción
            int filasAfectadas = pstmt.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void eliminarDatosfilaAPartirID(Statement conexionBBDD, String id){
        try{
            // Esto solo lo voy a probar una vez, a ver si funciona...
            // String query = "DELETE FROM empleados_bueno WHERE id_empleado="+id+";";
            String query = "DELETE FROM empleados_bueno WHERE id_empleado > ?;";
            Connection lol = conexionBBDD.getConnection();
            PreparedStatement pstmt = lol.prepareStatement(query);
            //Lo de abajo no funciona ya que he puesto para que lea un String, no un int...
//            pstmt.setString(1, Integer.parseInt(id));
            pstmt.setInt(1, Integer.parseInt(id));

            // Ejecuta la inserción
            int filasAfectadas = pstmt.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

//    public void modificarTabla(Statement conexionBBDD, String id, String campo, Object valor){
//        try{
//            String nombreCampo;
//            switch (Integer.parseInt(campo)){
//                case 1: nombreCampo = "nombre"; break;
//                case 2: nombreCampo = "puesto"; break;
//                case 3: nombreCampo = "tipo_jornada"; break;
//                case 4: nombreCampo = "email"; break;
//                case 5: nombreCampo = "telefono"; break;
//                case 6: nombreCampo = "fecha_contratacion"; break;
//                case 7: nombreCampo = "salario_hora"; break;
//                case 8: nombreCampo = "activo"; break;
//                case 9: nombreCampo = "departamento"; break;
//            }
//
//            String query = "UPDATE empleados_bueno\n" +
//                    "\n" +
//                    "SET ? = ?\n" +
//                    "\n" +
//                    "WHERE id_empleado = ?;";
//            Connection lol = conexionBBDD.getConnection();
//            PreparedStatement pstmt = lol.prepareStatement(query);
//            pstmt.setString(1, campo);
//            pstmt.setObject(2, valor);
//            pstmt.setInt(3, Integer.parseInt(id));
//
//            int filasAfectadas = pstmt.executeUpdate();
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//    }

    public void modificarTabla(Statement conexionBBDD, String id, String campo, Object valor){
        // 1. Obtener el nombre de la columna real
        String nombreCampo = null;
        switch (Integer.parseInt(campo)){
            case 1: nombreCampo = "nombre"; break;
            case 2: nombreCampo = "puesto"; break;
            case 3: nombreCampo = "tipo_jornada"; break;
            case 4: nombreCampo = "email"; break;
            case 5: nombreCampo = "telefono"; break;
            case 6: nombreCampo = "fecha_contratacion"; break;
            case 7: nombreCampo = "salario_hora"; break;
            case 8: nombreCampo = "activo"; break;
            case 9: nombreCampo = "departamento"; break;
            default: throw new IllegalArgumentException("Opción de campo inválida: " + campo);
        }

        try{
            // 2. CONSTRUIR LA CONSULTA SQL: ¡Usar el nombreCampo directamente!
            //    Solo se usa el marcador de posición (?) para el VALOR y el ID.
            String query = "UPDATE empleados_bueno SET " + nombreCampo + " = ? WHERE id_empleado = ?";

            Connection lol = conexionBBDD.getConnection();
            PreparedStatement pstmt = lol.prepareStatement(query);

            // 3. Asignar los valores (el primer valor ahora es el VALOR a actualizar)
            pstmt.setObject(1, valor);
            pstmt.setInt(2, Integer.parseInt(id));

            int filasAfectadas = pstmt.executeUpdate();
        } catch (Exception e) {
            // Mejor práctica: no atrapar excepciones genéricas (Exception), sino SQL (SQLException)
            throw new RuntimeException("Error al modificar la tabla en " + nombreCampo, e);
        }
    }
}
