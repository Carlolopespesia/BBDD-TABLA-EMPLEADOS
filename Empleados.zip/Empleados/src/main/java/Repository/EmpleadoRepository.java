package Repository;

import java.sql.*;
import java.util.Arrays;
import java.util.Properties;


public class EmpleadoRepository {

    //Definimos una url de la base de datos
    String url = "jdbc:postgresql://localhost:5432/CINELOKO";
    Properties props = new Properties();

    // El constructor con parámetros ya está bien si quieres usarlos
    public EmpleadoRepository(String url, Properties props) {
        this.url = url;
        this.props = props;
    }

    // Constructor sin argumentos: ¡Configuramos las propiedades aquí!
    public EmpleadoRepository() {
        // La url y props ya se inicializan arriba, solo necesitamos configurar props
        this.props.setProperty("user", "postgres");
        this.props.setProperty("password", "postgres");
        // No es necesario: this.url = url; o this.props = props; porque ya se hizo arriba
    }

    public Statement conexionBBDD(String url, Properties props){
        try{
            //Estos dos los había puesto en el paréntesis de try para manejar su memoria, pero eso hacía que se perdiera la conexión co la BBDD al finalizar el try
            // ********************************************************************
            Connection conn = DriverManager.getConnection(url, props);
            Statement statement = conn.createStatement();
            // ********************************************************************
            System.out.println("Versión de la base de datos");
            System.out.println(conn.getMetaData().getDatabaseProductVersion());
            return statement;
        }catch(SQLException e){
            System.out.println("Error connecting to database " + Arrays.toString(e.getStackTrace()));
        }
        return null;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Properties getProps() {
        return props;
    }

    public void setProps(Properties props) {
        this.props = props;
    }

    public String leerTablaID(Statement conexionBBDD, String id){
        String query = "SELECT *\n" +
                "FROM empleados_bueno\n" +
                "WHERE empleados_bueno.id_empleado ="+id+";";
        return leerTabla(conexionBBDD, query);
    }

    public String leerTodaTabala(Statement conexionBBDD){
        String query = "SELECT * FROM empleados_bueno;";
        return leerTabla(conexionBBDD, query);
    }

    public String leerTabla(Statement conexionBBDD, String query){
        try{
            ResultSet resultSet = conexionBBDD.executeQuery(query);
            String datosEmpleado = "";
            while (resultSet.next()) {
                // Extraer los valores por el nombre de la columna o su índice (empezando en 1)
                int id = resultSet.getInt("id_empleado");
                String valor1 = resultSet.getString("nombre");
                String puesto = resultSet.getString("puesto");
                String tipoJornada = resultSet.getString("tipo_jornada");
                String email = resultSet.getString("email");
                int telefono = resultSet.getInt("telefono");
                String fContratacion = resultSet.getString("fecha_contratacion");
                Float sHora = resultSet.getFloat("salario_hora");
                Boolean activo = resultSet.getBoolean("activo");

                // Inicializamos un String con la primera línea o un separador
                datosEmpleado += "-----------------------------------\n";

                // Concatenamos cada línea usando "\n" para el salto de línea
                datosEmpleado += "ID: " + id + "\n";
                datosEmpleado += "Nombre: " + valor1 + "\n"; // Asumiendo que 'valor1' es el nombre
                datosEmpleado += "Puesto: " + puesto + "\n";
                datosEmpleado += "Tipo de Jornada: " + tipoJornada + "\n";
                datosEmpleado += "Email: " + email + "\n";
                datosEmpleado += "Teléfono: " + telefono + "\n";
                datosEmpleado += "Fecha de Contratación: " + fContratacion + "\n";
                datosEmpleado += "Salario por Hora: " + sHora + "\n";
                datosEmpleado += "Activo: " + activo + "\n";
                datosEmpleado += "-----------------------------------\n";
            }
            // Devolvemos el string completo una sola vez
            return datosEmpleado;
        } catch (SQLException e) {
            System.out.println("Error connecting to database " + Arrays.toString(e.getStackTrace()));
        }
        return "";
    }

    public void insertarDatos(Statement conexionBBDD,
                              String nombre,
                              String puesto,
                              String tipoJornada,
                              String email,
                              String telefono,
                              String fechaContratacion,
                              double salarioHora,
                              String activo){

        try{
            String query = "INSERT INTO empleados_bueno (" +
                    "nombre, puesto, tipo_jornada, email, telefono, fecha_contratacion, salario_hora, activo) " +
                    "VALUES ('" + nombre + "', '" + puesto + "', '" + tipoJornada + "', '" + email + "', '" + telefono + "', '" + fechaContratacion + "', " + salarioHora + ", " + activo + ")";
            conexionBBDD.executeQuery(query);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}
