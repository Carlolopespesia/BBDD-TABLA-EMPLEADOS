package Main;

import Service.EmpleadosService;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public void main(String[] args){

        EmpleadosService SERVICIOS = new EmpleadosService();


        System.out.println("¿Qué quieres hacer?");
        System.out.println("(1) Leer");
        System.out.println("(2) Insertar");
        System.out.println("(3) Eliminar");
        System.out.println("(4) Modificar");
        Scanner sc = new Scanner(System.in);
        int e1 = sc.nextInt();
        sc.nextLine();
        if(e1==1){
            System.out.println("¿Qué quieres hacer?");
            System.out.println("(1) Leer toda la tabla");
            System.out.println("(2) Leer la tabla por id");
            System.out.println("(3) Salir de la lectura");
            int e2 = sc.nextInt();
            if(e2==1){
                System.out.println("HAS ELEGIDO LEER TODA LA TABLA");
                System.out.println(SERVICIOS.findallempleados());
            }else if(e2==2){
                System.out.println("HAS ELEGIDO BUSCAR POR ID");
                System.out.println("Introduce el id");
                int id = sc.nextInt();
                System.out.println(SERVICIOS.findallempleadosID(String.valueOf(id)));
            }else if(e2==3){
                System.out.println("Has elegido NO leer la tabla");
            }
            else{
                System.out.println("Opción incorrecta");
            }
        }else if(e1==2){
            System.out.println("¿Qué quieres hacer?");
            System.out.println("(1) Insertar una nueva fila en la tabla");
            System.out.println("(2) Salir de la insercción");
            int e2 = sc.nextInt();
            // Esto se pone para limpiar el buffer del input con e2 (java es una mierda)
            sc.nextLine();
            if(e2==1){
                System.out.println("Inserta el nombre: ");
                String nombre = sc.nextLine();
                System.out.println("Introduce el puesto");
                String puesto = sc.nextLine();
                System.out.println("Introduce el tipo de jornada");
                System.out.println("(1) Completa");
                System.out.println("(2) Parcial");
                String tipoJornada = "NA";
                boolean ctr3 = true;
                while(ctr3){
                    // Manejo del error con try-catch para evitar crash si no es un número
                    try {
                        int tipo = sc.nextInt();
                        if(tipo==1){
                            tipoJornada = "Completa";
                            ctr3 = false; // Detener el bucle
                        }else if(tipo==2){
                            tipoJornada = "Parcial";
                            ctr3 = false; // Detener el bucle
                        }else{
                            System.out.println("Opción no correcta. Intenta de nuevo (1 o 2):");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Entrada inválida. Introduce un número (1 o 2):");
                        sc.nextLine(); // Consumir la entrada inválida para evitar un bucle infinito
                    }
                }
                sc.nextLine(); // <<< CORRECCIÓN: Limpiar buffer después de leer int (tipo)

                System.out.println("Introduce el email");
                String email = sc.nextLine();

                System.out.println("Introduce el teléfono");
                String telefono = sc.nextLine();


                System.out.println("Introduce la fecha de contratación: ");
                System.out.println("Introduce el año:");
                String ano = sc.nextLine();
                System.out.println("Introduce el mes de contratación:");
                String mes = sc.nextLine();
                System.out.println("Introduce el día de contratación:");
                String dia = sc.nextLine();
                String fechaContratacion = ano+"-"+mes+"-"+dia;


                System.out.println("Introduce el salario hora");
//              double salarioHora = sc.nextDouble(); // <<< CORRECCIÓN: Descomentar para input real
//                sc.nextLine(); // <<< CORRECCIÓN: Limpiar buffer después de leer double
                String salarioHorainput = sc.nextLine();
                Double salarioHora = Double.parseDouble(salarioHorainput.replace(',', '.'));

                System.out.println("Decide si está activo o no:");

                System.out.println("(1) True");
                System.out.println("(2) False");

                int activoOP = sc.nextInt();
                sc.nextLine();

                boolean activo;
                if(activoOP==1){
                    activo = true;
                }else if(activoOP==2){
                    activo = false;
                }else{
                    activo = false;
                }


                System.out.println("Introduce el departamento");
                String departamento = sc.nextLine();


                SERVICIOS.insertarDatos(
                nombre,
                puesto,
                tipoJornada,
                email,
                telefono,
                fechaContratacion,
                salarioHora,
                activo,
                departamento
                );
            }else if(e2==2){
                System.out.println("Has elegido NO insertar datos en la tabla");
            }else{
                System.out.println("Opción incorrecta");
            }
        }else if(e1==3){
            System.out.println("¿Qué quieres hacer?");
            System.out.println("(1) Eliminar contenido de la tabla");
            System.out.println("(2) Salir de la eliminación");

            int e2 = sc.nextInt();
            // Esto se pone para limpiar el buffer del input con e2 (java es una mierda)
            sc.nextLine();

            if(e2==1){
                System.out.println("¿Qué quieres hacer?");
                System.out.println("(1) Eliminar una fila de la tabla");
                System.out.println("(2) Eliminar las filas a partir de una fila");

                int e3 = sc.nextInt();
                // Esto se pone para limpiar el buffer del input con e2 (java es una mierda)
                sc.nextLine();

                if(e3==1){
                    System.out.println("Selecciona el id: ");
                    String idOp = sc.nextLine();
                    SERVICIOS.eliminarDatosfila(idOp);
                }else if(e3==2){
                    System.out.println("RECUERDA, se eliminan TODAS las filas a partir del id seleccionado (éste no incluido)");
                    System.out.println("Selecciona el id: ");
                    String idOp = sc.nextLine();
                    SERVICIOS.eliminarDatosfilaAPartirID(idOp);
                }
            }else if(e2==2){
                System.out.println("Has elegido salir de la eliminación...");
            }else{
                System.out.println("No has elegido una opción correcta");
            }

        }else if(e1==4){
            System.out.println("Elige el ID de la fila que quieras modificar: ");
            String id = sc.nextLine();

            System.out.println("Elige un campo para modificar: ");
            System.out.println("(1) nombre\n" +
                    "(2) puesto\n" +
                    "(3) tipo_jornada\n" +
                    "(4) email\n" +
                    "(5) telefono\n" +
                    "(6) fecha_contratacion\n" +
                    "(7) salario_hora\n" +
                    "(8) activo\n" +
                    "(9) departamento");

            String campoOP = sc.nextLine();

            Object valorOP = null;
            switch (Integer.parseInt(campoOP)){
                case 1: System.out.println("Introduce el nombre: "); valorOP = sc.nextLine(); break;
                case 2: System.out.println("Introduce el puesto: "); valorOP = sc.nextLine(); break;
                case 3: System.out.println("Introduce el tipo de jornada: ");
                    System.out.println("(1) Completa");
                    System.out.println("(2) Parcial");
                    int opcion = sc.nextInt(); sc.nextLine(); valorOP = (opcion==1) ? "Completa" : "Parcial"; break;
                case 4:
                    System.out.println("Introduce el email: "); valorOP = sc.nextLine(); break;
                case 5:
                    System.out.println("Introduce el número de teléfono: "); valorOP = sc.nextLine(); break;
                case 6:
                    System.out.println("Introduce la fecha de contratación: ");
                    System.out.println("Introduce el año: ");
                    String ano = sc.nextLine();
                    System.out.println("Introduce el mes: ");
                    String mes = sc.nextLine();
                    System.out.println("Introduce el día: ");
                    String dia = sc.nextLine();
                    String fecha = ano + "-" + mes + "-" + dia;
//                    valorOP = LocalDate.parse(fecha);
//                    break;
                    // Solución: Definir un formato que acepte meses/días de 1 o 2 dígitos
                    // 'y': año, 'M': mes (sin cero inicial), 'd': día (sin cero inicial)
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("y-M-d");

                    valorOP = LocalDate.parse(fecha, formatter); // Usar el formatter
                    break;
                case 7:
                    System.out.println("Introduce el salario por hora: ");
                    valorOP = sc.nextLine();
                    valorOP = Double.parseDouble(valorOP.toString().replace(',','.'));
                    break;
                case 8:
                    System.out.println("¿Está activo o no?");
                    System.out.println("(1) Activo");
                    System.out.println("(2) No activo");
                    int klk = sc.nextInt(); sc.nextLine(); valorOP = (klk==1) ? true : false; break;
                case 9:
                    System.out.println("Introudce el departamento");
                    valorOP = sc.nextLine(); break;
            }
            
            SERVICIOS.modificarTabla(id, campoOP, valorOP);
        }else{
            System.out.println("HAS ELEGIDO NO LEER LA TABLA");
        }
        sc.close();
    }
}
