package Main;

import Service.EmpleadosService;

import java.util.Scanner;

public class Main {
    public void main(String[] args){

        EmpleadosService SERVICIOS = new EmpleadosService();


        System.out.println("¿Qué quieres hacer?");
        System.out.println("(1) Leer");
        System.out.println("(2) Insertar");
        System.out.println("(3) Modificar");
        System.out.println("(4) Eliminar");
        Scanner sc = new Scanner(System.in);
        int e1 = sc.nextInt();
        if(e1==1){
            System.out.println("¿Qué quieres hacer?");
            System.out.println("(1) Leer toda la tabla");
            System.out.println("(2) Leer la tabla por id");
            System.out.println("(3) Salir de la lectura");
            int e2 = sc.nextInt();
            if(e2==1){
                System.out.println("HAS ELEGIDO LEER TODA LA TABLA");
                System.out.println(SERVICIOS.findallempleados());
            }else if(e2==2){
                System.out.println("HAS ELEGIDO BUSCAR POR ID");
                System.out.println("Introduce el id");
                int id = sc.nextInt();
                System.out.println(SERVICIOS.findallempleadosID(String.valueOf(id)));
            }else if(e2==3){
                System.out.println("Has elegido NO leer la tabla");
            }
            else{
                System.out.println("Opción incorrecta");
            }
        }else if(e1==2){
            System.out.println("¿Qué quieres hacer?");
            System.out.println("(1) Insertar una nueva fila en la tabla");
            System.out.println("(2) Salir de la insercción");
            int e2 = sc.nextInt();
            if(e2==1){
                System.out.println("Inserta el nombre: ");
                String nombre = sc.nextLine();
                System.out.println("Introduce el puesto");
                String puesto = sc.nextLine();
                System.out.println("Introduce el tipo de jornada");
                System.out.println("(1) Completa");
                System.out.println("(2) Parcial");
                String tipoJornada;
                boolean ctr3 = true;
                try{
                 while(ctr3){
                    int tipo = sc.nextInt();
                    if(tipo==1){
                        tipoJornada = "Completa";
                        break;
                    }else if(tipo==2){
                        tipoJornada = "Parcial";
                        break;
                    }else{
                        System.out.println("Opción no correcta");
                    }
                 }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }finally {
                    tipoJornada = "NA";
                }

                System.out.println("Introduce el email");
                String email = sc.nextLine();

                System.out.println("Introduce el teléfono");
                String telefono = sc.nextLine();

                System.out.println("Introduce la fecha de contratación: ");
                String fechaContratacion = sc.nextLine();

                System.out.println("Introduce el salario hora");
                // double salarioHora = sc.nextDouble();
                double salarioHora = 5.5;

                System.out.println("Decide si está activo o no (Si/No):");

                String activo = sc.nextLine();

                SERVICIOS.insertarDatos(
                nombre,
                puesto,
                tipoJornada,
                email,
                telefono,
                fechaContratacion,
                salarioHora,
                activo
                );
            }else if(e2==2){
                System.out.println("Has elegido NO insertar datos en la tabla");
            }else{
                System.out.println("Opción incorrecta");
            }
        }else{
            System.out.println("HAS ELEGIDO NO LEER LA TABLA");
        }
        sc.close();
    }
}
