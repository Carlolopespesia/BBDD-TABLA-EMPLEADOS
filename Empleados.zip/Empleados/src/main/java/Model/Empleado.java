package Model;


import java.util.Date;

public class Empleado {

    int id_empleado;
    String nombre;
    String puesto;
    String tipo_jornada;
    String email;
    int telefono;
    Date fecha_contratcion;
    float salario_hora;
    boolean activo;

    public Empleado(int id_empleado, String nombre, String puesto, String email, String tipo_jornada, int telefono, Date fecha_contratcion, float salario_hora, boolean activo) {
        this.id_empleado = id_empleado;
        this.nombre = nombre;
        this.puesto = puesto;
        this.email = email;
        this.tipo_jornada = tipo_jornada;
        this.telefono = telefono;
        this.fecha_contratcion = fecha_contratcion;
        this.salario_hora = salario_hora;
        this.activo = activo;
    }

    public Empleado() {
    }

    public int getId_empleado() {
        return id_empleado;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPuesto() {
        return puesto;
    }

    public String getTipo_jornada() {
        return tipo_jornada;
    }

    public String getEmail() {
        return email;
    }

    public int getTelefono() {
        return telefono;
    }

    public Date getFecha_contratcion() {
        return fecha_contratcion;
    }

    public float getSalario_hora() {
        return salario_hora;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public void setTipo_jornada(String tipo_jornada) {
        this.tipo_jornada = tipo_jornada;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void setFecha_contratcion(Date fecha_contratcion) {
        this.fecha_contratcion = fecha_contratcion;
    }

    public void setSalario_hora(float salario_hora) {
        this.salario_hora = salario_hora;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "id_empleado=" + id_empleado +
                ", nombre='" + nombre + '\'' +
                ", puesto='" + puesto + '\'' +
                ", tipo_jornada='" + tipo_jornada + '\'' +
                ", email='" + email + '\'' +
                ", telefono=" + telefono +
                ", fecha_contratcion=" + fecha_contratcion +
                ", salario_hora=" + salario_hora +
                ", activo=" + activo +
                '}';
    }
}
