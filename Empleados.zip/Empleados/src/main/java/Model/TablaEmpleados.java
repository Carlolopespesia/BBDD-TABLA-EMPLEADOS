package Model;

// Esto va a ser las listas de las columnas de la tabla (cada columna es un objeto Empleado.java)


import java.util.ArrayList;
import java.util.Date;

public class TablaEmpleados {

    //ArrayList<TipoDeElemento> nombreVariable = new ArrayList<TipoDeElemento>();

    ArrayList<Integer> id_empleado = new ArrayList<Integer>();

    ArrayList<String> nombre = new ArrayList<String>();

    ArrayList<String> puesto = new ArrayList<String>();

    ArrayList<String> tipo_jornada = new ArrayList<String>();

    ArrayList<String> email = new ArrayList<String>();

    ArrayList<Integer> telefono = new ArrayList<Integer>();

    ArrayList<Date> fecha_contratcion = new ArrayList<Date>();

    ArrayList<Float> salario_hora = new ArrayList<Float>();

    ArrayList<Boolean> activo = new ArrayList<Boolean>();




}
